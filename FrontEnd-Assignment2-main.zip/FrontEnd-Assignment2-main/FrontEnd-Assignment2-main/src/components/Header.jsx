import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { NavLink } from "react-router-dom";

export default function Header() {
  return (
    <Navbar className="mainNav" collapseOnSelect expand="lg" style={{ backgroundColor: 'teal' }} variant="dark">
      <Container>
        <Navbar.Brand as={NavLink} to="/" className="align-center">
          <p className="logo-text">HollyDude</p>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-center">
          <Nav className="me-auto d-flex justify-content-around w-100">
            <Nav.Link as={NavLink} to="/" className="nav-link-custom">Home</Nav.Link>
            <Nav.Link as={NavLink} to="/movies" className="nav-link-custom">Movies</Nav.Link>
            <Nav.Link as={NavLink} to="/screen-list" className="nav-link-custom">Screenings</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}