import React from 'react';

export default function Footer() {
  return (
    <div className="bg-black py-3" style={{ position: 'fixed', bottom: 0, left: 0, width: '100%' }}>
      <div className="container-fluid px-0">
        <p className="text-center m-0 footer">
          &copy; HollyDude, 2024
        </p>
      </div>
    </div>
  );
}