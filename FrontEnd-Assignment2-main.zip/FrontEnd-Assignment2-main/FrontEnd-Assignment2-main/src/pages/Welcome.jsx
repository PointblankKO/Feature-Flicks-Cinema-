import Button from 'react-bootstrap/Button';
import { NavLink } from "react-router-dom";

export default function Welcome() {
  return (
    <div className="frontPage p-5">
      <div className="innerFront p-5">
        <h2>Welcome to Feature Flicks Cinema</h2>
        <p>Experience the magic of cinema like never before. From the latest blockbusters to timeless classics, Feature Flicks Cinema has something for everyone.</p>
        <p>Explore our extensive collection of movies, book your tickets, and embark on a cinematic journey that will leave you spellbound.</p>
        <style>
          {`
            .custom-button {
              color: white !important;
              background-color: teal !important;
              border-color: teal !important;
            }

            .custom-button:hover {
              color: black !important;
            }
          `}
        </style>
        <NavLink to="/movies">
          <Button className="mt-5 m-3 px-4 py-2 custom-button" variant="outline-primary">
            Go to Movies
          </Button>
        </NavLink>
        <NavLink to="/screen-list">
          <Button className="mt-5 m-3 px-4 py-2 custom-button" variant="outline-primary" type="submit">
            Go to Screenings
          </Button>
        </NavLink>
      </div>
    </div>
  );
}