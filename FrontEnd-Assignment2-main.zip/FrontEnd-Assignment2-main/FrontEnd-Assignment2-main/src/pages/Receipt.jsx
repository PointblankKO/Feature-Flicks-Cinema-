import { useLocation } from "react-router-dom";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";

export default function Receipt() {
  let { search } = useLocation();
  search = new URLSearchParams(search);
  const total = search.get("total");
  const movie = search.get("movie");
  const auditorium = search.get("auditorium");
  const seats = JSON.parse(search.get("seats"));
  const time = search.get("time");
  const [adults, seniors, children] = JSON.parse(search.get("type"));
  const ticketNumber = search.get("no");

  return (
    <div className="receipt d-flex flex-column align-items-center text-center px-md-5">
      <h2 className="display-4 pt-3">Booking Confirmation</h2>
      <p>Thank you for choosing Feature Flicks Cinema! Your booking has been successfully completed. check the summary below:</p>
      <h2 className="mb-3">{movie}</h2>
      <h4>Booking Number: {ticketNumber}</h4>
      <Table variant="light" style={{ width: "80%" }}>
        <tbody>
          <tr>
            <th>Total Price</th>
            <td style={{ color: "black", fontWeight: "bold" }}>{total} SEK</td>
          </tr>
          <tr>
            <th>Ticket Amount</th>
            <td>{adults + seniors + children}</td>
          </tr>
          {adults !== 0 && (
            <tr>
              <td>Adult tickets</td>
              <td>{adults}</td>
            </tr>
          )}
          {seniors !== 0 && (
            <tr>
              <td>Senior Tickets</td>
              <td>{seniors}</td>
            </tr>
          )}
          {children !== 0 && (
            <tr>
              <td>Children Tickets</td>
              <td>{children}</td>
            </tr>
          )}
          <tr>
            <th>Auditorium</th>
            <td>{auditorium}</td>
          </tr>
          <tr>
            <th>Screening time</th>
            <td>{time}</td>
          </tr>
        </tbody>
      </Table>
      <h3 className="mt-5">Seat Numbers:</h3>
      <Table hover variant="light" className="pb-5" style={{ width: "80%" }}>
        <thead>
          <tr>
            <th>Row</th>
            <th>Seats</th>
          </tr>
        </thead>
        <tbody>
          {seats.map((seat, row) =>
            !seat ? null : (
              <tr>
                <th>{row}</th>
                <td>{seat.join(", ")}</td>
              </tr>
            )
          )}
        </tbody>
      </Table>
      <Button className="addToYourListButton mt-3" variant="outline-primary">
        Add to Your List
      </Button>
      <p className="mt-5">We hope you have a delightful time watching {movie} at Feature Flicks Cinema! Enjoy your movie experience!</p>
    </div>
  );
}




