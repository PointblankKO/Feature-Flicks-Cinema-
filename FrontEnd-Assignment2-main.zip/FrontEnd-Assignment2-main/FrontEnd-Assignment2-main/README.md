
Feature Flicks - The Cinema
This project is a small web application built using React, HTML/jsx, CSS, Bootstrap, and JavaScript.
 It consumes data from a pre-existing REST API to provide users with information about movies, screenings,
  and categories. The main components of the project are:

Main Component:
App Component:
The App component serves as the entry point for the application.
It contains the site's structure, including the header with the HeaderMenu component,
the main area that houses all the routes, and the footer with the Footer component.

Pages Components:
Welcome Page:
The Welcome page serves as the starting point of the website.

Movies Page:
The Movies page displays a list of movies and screenings,
categorized by genres. Users can filter movies by genre and search for specific movies.
Clicking on a movie takes the user to the Movie Details page.

Movie Details Page:
The Movie Details page provides comprehensive information about a selected movie.

Screening List Page:
On the Screening List page, users can view available seats and book them for a screening.
The booking fee varies based on age groups.

Receipt Page:
After successfully booking a movie screening, users are redirected to the Receipt page.
Here, they receive a booking number and all necessary details about the booked movie.

Particular Components:
Header Component:
The Header component is a react-bootstrap header.

Footer Component:
The Footer component is a simple sticky footer.

Display Seats Component:
The Display Seats component allows users to select available seats for booking.

Development:
To launch the project locally, follow these steps:

Clone the repository from GitHub.
Navigate to the project directory.
Install dependencies by running npm install or yarn install.
Launch the Vite development server by running npm run dev or yarn dev.
Access the application in your browser at the provided localhost URL.

- More about the assignment:
https://da218.lms.nodehill.se/article/assignment-2-of-2-feature-flicks-the-cinema
