import React, { useState } from "react";
import InputGroup from "react-bootstrap/InputGroup";
import Form from "react-bootstrap/Form";

export default function Search() {
  const [searchText, setSearchText] = useState("");

  const handleChange = (event) => {
    setSearchText(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
  };

  return (
    <Form onSubmit={handleSubmit} className="bg-light">
      <InputGroup className="mb-3">
        <Form.Control
          className="bg-light rounded-pill" 
          placeholder="Search"
          value={searchText}
          onChange={handleChange}
          style={{
            border: searchText ? "1px solid black" : "1px solid powderblue",
            borderColor: "teal",
          }}
        />
      </InputGroup>
    </Form>
  );
}